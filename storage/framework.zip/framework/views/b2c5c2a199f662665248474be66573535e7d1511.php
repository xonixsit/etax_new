<?php echo $__env->make('admin.dataTableLayout',[
    'title' => 'Clients',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/client/index.blade.php ENDPATH**/ ?>