


<?php $__env->startSection('content'); ?>
    <personal-info :personal-info='<?php echo json_encode($personal_information??[], 15, 512) ?>'></personal-info>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/personal_info/personal.blade.php ENDPATH**/ ?>