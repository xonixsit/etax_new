


<?php $__env->startSection('title', 'Tax Document Upload'); ?>

<?php $__env->startSection('content'); ?>
    <tax-document-uploader :document-details='<?php echo json_encode($document??[], 15, 512) ?>'></tax-document-uploader>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/documents/tax_document_upload.blade.php ENDPATH**/ ?>