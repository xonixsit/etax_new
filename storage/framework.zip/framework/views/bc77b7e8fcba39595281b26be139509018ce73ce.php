


<?php $__env->startSection('title', 'File Status'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="h4">File Status</div>

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb py-0 my-0">
                            <?php $__currentLoopData = range(request('year')-1, request('year')+1 ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="breadcrumb-item <?php if($year == request('year')): ?> active <?php endif; ?> ">
                                    <?php if($year != request('year')): ?>
                                        <a href="<?php echo e(route(\Illuminate\Support\Facades\Route::currentRouteName(),['user'=>$user->id, 'year'=>$year])); ?>">
                                            <?php echo e($year); ?>

                                        </a>
                                    <?php else: ?>
                                        <?php echo e($year); ?>

                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </nav>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="file_status_name" class="text-dark">Update File Status of "<?php echo e($user->name); ?>

                                "</label>

                            <form method="post"
                                  action="<?php echo e(route('admin.file_status.add_file_status',['user'=>$user->id,'year'=>request('year')])); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">

                                    <select class="form-control" id="filter-status" name="status">
                                        <option value="">Select Status</option>
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            Submit
                                        </button>
                                    </div>

                                </div>

                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </form>
                        </div>
                        <div class="offset-md-8"></div>
                        <div class="col-12">
                            <h5 class="py-3 font-weight-light">File Status</h5>
                        </div>


                        <div class="col-12">
                            <?php echo e($dataTable->table()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.css"/>
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.0.3/css/buttons.dataTables.min.css"/>

    <style>
        .breadcrumb-item + .breadcrumb-item::before {
            content: "|";
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="//cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.js"></script>
    <script src="//cdn.datatables.net/buttons/1.0.3/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>

    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/file_status/user_file.blade.php ENDPATH**/ ?>