

<?php $__env->startSection("title", "Client Details"); ?>



<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="h4">User View</div>

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb py-0 my-0">
                            <?php $__currentLoopData = range(request('year')-1, request('year')+1 ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="breadcrumb-item <?php if($year == request('year')): ?> active <?php endif; ?> ">
                                    <?php if($year != request('year')): ?>
                                        <a href="<?php echo e(route(\Illuminate\Support\Facades\Route::currentRouteName(),['user'=>$user->id, 'year'=>$year])); ?>">
                                            <?php echo e($year); ?>

                                        </a>
                                    <?php else: ?>
                                        <?php echo e($year); ?>

                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.personal_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.spouse_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.dependent_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.bank_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.employe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.project_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.asset', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.expenses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.miscellaneous', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-6 my-3">
            <?php echo $__env->make('partial.residency', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('css'); ?>
    <style>
        .control-group {
            display: flex;
            margin-top: 5px;
            border-bottom: 1px solid #e9ecef;
        }

        .control-label {
            font-weight: bold;
            color: #000000;
        }

        .controls {
            margin-left: .5rem;
        }

        .card-header {
            font-weight: bold;
            color: #00588d;
        }
    </style>















<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin-base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/client/details.blade.php ENDPATH**/ ?>