

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col">
            <h4 class="font-weight-light text-info">Welcome back! <?php echo e(Auth::user()->name); ?></h4>
            <hr/>
        </div>
    </div>

    <div class="row">

        <?php if(($role == 'staff' && strpos($permissions, 'client') !== false) || $role == 'admin'): ?>
            <a href="<?php echo e(route('admin.client.index')); ?>" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-info mt-n4">
                        <i class="fa fa-users"></i>
                        <b>Total Clients</b>
                    </div>


                    <div class="h2 font-weight-light text-center text-info py-3">
                        <?php echo e($dashboard['total_clients']); ?>

                    </div>
                </div>
            </a>

        <?php endif; ?>

        <?php if($role == 'admin' ): ?>
            <a href="<?php echo e(route('admin.staff.index')); ?>" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-warning mt-n4">
                        <i class="fa fa-address-book"></i>
                        <b>Total Staff Members </b>
                    </div>


                    <div class="h2 font-weight-light text-center text-warning py-3">
                        <?php echo e($dashboard['total_staff']); ?>

                    </div>
                </div>
            </a>
        <?php endif; ?>


        <?php if(($role == 'staff' && strpos($permissions, 'invoice') !== false) || $role == 'admin'): ?>
            <a href="<?php echo e(route('admin.invoice.index')); ?>" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-primary mt-n4">
                        <i class="fa fa-dollar"></i>
                        <b>Total Paid Invoice</b>
                    </div>
                    <div class="h2 font-weight-light text-center text-primary py-3">
                        <?php echo e($dashboard['invoice_paid']); ?>

                    </div>
                </div>
            </a>

            <a href="<?php echo e(route('admin.invoice.index')); ?>" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-danger mt-n4">
                        <i class="fa fa-ofuser-secret"></i>
                        <b>Total Pending Invoice</b>
                    </div>
                    <div class="h2 font-weight-light text-center text-danger py-3">
                        <?php echo e($dashboard['invoice_unpaid']); ?>

                    </div>
                </div>
            </a>
        <?php endif; ?>

        <?php if(($role == 'staff' && strpos($permissions, 'file') !== false) || $role == 'admin'): ?>

            <a href="#" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-dark mt-n4">
                        <i class="fa fa-file"></i>
                        <b>File Completed</b>
                    </div>
                    <div class="h2 font-weight-light text-center text-dark py-3">
                        <?php echo e($dashboard['total_file_completed']); ?>

                    </div>
                </div>
            </a>

            <a href="#" class="col-12 col-md-4 col-xl-3">
                <div class="d-block p-2 border rounded-lg shadow-sm mb-5">
                    <div class="alert alert-secondary mt-n4">
                        <i class="fa fa-file-excel-o"></i>
                        <b>File Incompleted</b>
                    </div>
                    <div class="h2 font-weight-light text-center text-secondary py-3">
                        <?php echo e($dashboard['total_file_uncompleted']); ?>

                    </div>
                </div>
            </a>

        <?php endif; ?>
    </div>

    <?php if(($role == 'staff' && strpos($permissions, 'invoice') !== false) || $role == 'admin'): ?>
        <admin-dashboard invoice="<?php echo e($dashboard['total_invoice']); ?>" revenue="<?php echo e($dashboard['total_revenue']); ?>"
                         avg="<?php echo e($dashboard['avg_revenue']??0); ?>"></admin-dashboard>

    <?php endif; ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>