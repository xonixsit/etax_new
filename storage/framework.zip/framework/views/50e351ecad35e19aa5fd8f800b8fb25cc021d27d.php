<div class="card">
    <div class="card-header">
        Dependent Details
    </div>
    <div class="card-body">

        <?php if($dependent_details->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>D.O.B</th>
                        <th>Relationship</th>
                        <th>SSN ITIN</th>
                        <th>Visa Status</th>
                        <th>Date Of Entry in US :</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dependent_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependent_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>

                            <td><?php echo e($dependent_detail->fname); ?></td>
                            <td><?php echo e($dependent_detail->mname); ?></td>
                            <td><?php echo e($dependent_detail->lname); ?></td>
                            <td><?php echo e($dependent_detail->date_of_birth); ?></td>
                            <td><?php echo e($dependent_detail->relationship); ?></td>
                            <td><?php echo e($dependent_detail->ssn); ?></td>
                            <td><?php echo e($dependent_detail->visa_status); ?></td>
                            <td><?php echo e($dependent_detail->date_of_entry_in_us); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/dependent_details.blade.php ENDPATH**/ ?>