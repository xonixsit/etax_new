

<?php $__env->startSection('title', $page->title); ?>


<?php $__env->startSection('content'); ?>
    <hr class="my-0"/>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="mb-3 font-weight-normal"><?php echo e($page->title); ?></h1>
                <?php echo $page->content; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/page.blade.php ENDPATH**/ ?>