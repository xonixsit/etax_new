


<?php $__env->startSection("title","User Tax Documents"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">

        <div class="card-header">
            <h3 class="card-title">User Tax Documents</h3>
        </div>

        <div class="card-body">
            <div class="row no-gutters bg-info py-2 px-1 text-white mb-2">
                <div class="col-1">
                    SL
                </div>
                <div class="col-4 px-1">
                    Title
                </div>
                <div class="col-4 px-1">
                    Browse File
                </div>
                <div class="col-3 px-1">
                    Remarks
                </div>
            </div>

            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row no-gutters py-2 border-bottom">
                    <div class="col-1">
                        <?php echo e($loop->index+1); ?>

                    </div>
                    <div class="col-4 px-1">
                        <?php echo e($document->title); ?>

                    </div>
                    <div class="col-4 px-1">
                        <ul class="list-group">
                            <?php $__currentLoopData = $document->upload; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="list-group-item  d-flex justify-content-between align-items-center py-1 px-2">
                                    <span><?php echo e($file->filename); ?></span>
                                    <div class="d-flex justify-content-center">

                                        <a href="<?php echo e(route('admin.download_user_tax_document', $file->id)); ?>" class="mx-3"><i
                                                class="fa fa-download"></i></a>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <div class="col-3 px-1">
                        <input type="text" class="form-control" disabled value="<?php echo e($document->comment); ?>">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/tax_document/user_tax_document.blade.php ENDPATH**/ ?>