
<html>
<head>

</head>

<body>
<p>Dear <?php echo e($user->name); ?>,</p>
<br>
<p>You are assigned an invoice.</p>

<p>Invoice Title: <?php echo e($invoice->name); ?></p>

<p>Description: <?php echo e($invoice->description); ?></p>

Please click on the below button or copy the below link and paste on the url to see the invoice details.
<p><a class='btn' href='<?php echo e($invoice_link); ?>'>Invoice Details</a></p>
<p>Link: <?php echo e($invoice_link); ?></p>
<br>
<p>Thanks<br><?php echo e(env('APP_NAME')); ?></p>
</body>

</html>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/mail/invoice.blade.php ENDPATH**/ ?>