<!DOCTYPE HTML>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title',"Welcome to eTaxPlanner"); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Laravel CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Current Year -->
    <meta name="year" content="<?php echo e(request()->route('year') ?? request('year') ?? date('Y')); ?>">


    <!-- font-awesome CSS -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/fonts/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- font-flaticon CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>" type="text/css" media="all"/>

    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="56x56" href="<?php echo e(asset('assets/images/fav-icon/icon.png')); ?>">
    <!-- bootstrap CSS -->

    <!-- meanmenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.min.css')); ?>" type="text/css" media="all"/>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" type="text/css" media="all"/>
    <!-- theme-default CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme-default.css')); ?>" type="text/css" media="all"/>
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" type="text/css" media="all"/>

    <script src="//www.google.com/recaptcha/api.js" async defer></script>


    <!-- google site key -->
    <meta name="google-site-verification" content="<?php echo e(env('RECAPTCHA_SITE_KEY')); ?>">

    <title><?php echo $__env->yieldContent("title","Welcome to Dashboard"); ?></title>


    <style>
        .sidebar-container {
            width: 16rem;
            background-color: #f1f1f1;
            border-right: 1px solid #ccc;
            font-size: .85rem;
        }

        .sidebar-container.closed {
            left: -16rem;
        }

        .main-container {
            flex: 1;
            background-color: #fff;
            padding: 1.2rem;
        }
    </style>

    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>


<?php echo $__env->make('shared._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<hr class="p-0 m-0"/>

<div class="d-flex">
    <div class="float-left align-self-stretch border-right">
        <div class="sidebar-container">
            <?php echo $__env->make('shared._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="main-container" id="app">
        <div class="container-fluid">

        <?php if(auth()->user()->role == 'user'): ?>

            <!-- BEGIN PAGE HEADER-->
                <ul class="breadcrumb">
                    <li>
                        <a href="" target="_blank">Home</a>
                        <span class="divider"> / </span>
                    </li>

                    <li>
                        <a href="" target="_blank">&nbsp;User</a>
                        <span class="divider"> / </span>
                    </li>

                    <?php for($i = 2; $i <= count(Request::segments()); $i++): ?>
                        <li>
                            <a class="text-capitalize"
                               href="<?php echo e(URL::to( implode( '/', array_slice(Request::segments(), 0 ,$i, true)))); ?>">
                                &nbsp;<?php echo e(Request::segment($i)); ?></a>
                            <span class="divider"> / </span>
                        </li>
                    <?php endfor; ?>

                    <li class="ml-auto"></li>
                    <?php $__currentLoopData = range(date('Y')+1, date('Y')-1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="ml-3 pl-3 border-left">
                            <a href="<?php echo e(route_with_year(Route::currentRouteName(),['year'=>$year])); ?>"
                               class="<?php if(request()->route('year') == $year): ?> font-weight-bold text-success <?php endif; ?> "><?php echo e($year); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            <?php endif; ?>


            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info', 'error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(session()->has( $message)): ?>
                    <div class="alert alert-<?php echo e($message == 'error' ? 'danger' : $message); ?>">
                        <?php echo e(session()->get($message)); ?>

                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php if(\App\Helpers\ProgressControl::hasProgress()): ?>
                <div class="alert alert-light mx-n3">
                <span class="text-info">
                    <i class="fa fa-exclamation"></i>
                    Your Progress
                </span>

                    <div class="progress">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                             style="width:<?php echo e(\App\Helpers\ProgressControl::getProgress()); ?>%" aria-valuenow="25"
                             aria-valuemin="0" aria-valuemax="100"><?php echo e(\App\Helpers\ProgressControl::getProgress()); ?>%
                        </div>
                    </div>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>


<!-- jquery js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/vendor/jquery-3.2.1.min.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
<script src="//stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
<!-- jquery meanmenu js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.meanmenu.js')); ?>"></script>
<!-- jquery scrollup js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.scrollUp.js')); ?>"></script>
<!-- theme js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>


<!-- Main App Script -->
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>

<script>
    $(document).ready(function () {
        $('.sidebar .sub-menu > a').click(function () {
            var last = $('.sub-menu.open', $('#sidebar'));
            last.removeClass("open");
            $('.arrow', last).removeClass("open");
            $('.sub', last).slideUp(200);
            var sub = $(this).next();
            if (sub.is(":visible")) {
                $('.arrow', $(this)).removeClass("open");
                $(this).parent().removeClass("open");
                sub.slideUp(200);
            } else {
                $('.arrow', $(this)).addClass("open");
                $(this).parent().addClass("open");
                sub.slideDown(200);
            }
            var o = ($(this).offset());
            diff = 200 - o.top;
            if (diff > 0)
                $(".sidebar-scroll").scrollTo("-=" + Math.abs(diff), 500);
            else
                $(".sidebar-scroll").scrollTo("+=" + Math.abs(diff), 500);
        });

        for (const sel in $('select')) {
            if ($('select')[sel].dataset.old || false) {
                $('select')[sel].value = $('select')[sel].dataset.old;
            }
        }
    });
</script>


<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>

<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/layouts/admin-base.blade.php ENDPATH**/ ?>