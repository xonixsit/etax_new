<div class="card">
    <div class="card-header">
        Assets
    </div>

    <div class="card-body">

        <style type="text/css">
            .asset_details_table input {
                width: 90px;
            }
        </style>

        <div class="table-responsive">
            <table class="table table-striped table-sm table-bordered">
                <tr class="asset_tex_payer_table_header">
                    <th class="">SL No</th>
                    <th class="">Asset Name</th>
                    <th class="">Date Of Purchase</th>
                    <th class="">% Used in Business</th>
                    <th class="">Cost of Acquisition</th>
                    <th class="">Any Reiumbersement</th>
                </tr>


                <?php $__currentLoopData = range(0, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="">
                        <td><?php echo e($item + 1); ?></td>
                        <td><?php echo e($asset_details->details['title'][$item] ?? ''); ?></td>
                        <td><?php echo e($asset_details->details['dateofpurchase'][$item] ?? ''); ?></td>
                        <td><?php echo e($asset_details->details['business'][$item] ?? ''); ?></td>
                        <td><?php echo e($asset_details->details['acquisition'][$item] ?? ''); ?></td>
                        <td><?php echo e($asset_details->details['reiumbersement'][$item] ?? ''); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/asset.blade.php ENDPATH**/ ?>