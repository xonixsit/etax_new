<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Start eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->
    <div class="breatcome_area d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breatcome_title">
                        <div class="breatcome_title_inner pb-2">
                            <h2>About Us</h2>
                        </div>
                        <div class="breatcome_content">
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right"></i> <a href="#">
                                        Pages</a> <i class="fa fa-angle-right"></i> <span>About Us</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->


    <!--==================================================-->
    <!----- Start eTaxPlanner About Area ----->
    <!--==================================================-->
    <div class="about_area pt-85 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-6">
                    <div class="about_thumb">
                        <img src="<?php echo e(storage_asset($about->image)); ?>" alt=""/>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-6">
                    <div class="section_title text_left mb-40 mt-3">
                        <div class="section_sub_title uppercase mb-3">
                            <h6><?php echo e($about->note); ?></h6>
                        </div>
                        <div class="section_main_title">
                            <h1><?php echo e($about->heading); ?></h1>
                        </div>
                        <div class="em_bar">
                            <div class="em_bar_bg"></div>
                        </div>
                        <div class="section_content_text bold pt-5">
                            <p><?php echo e($about->subheading); ?></p>
                        </div>
                    </div>
                    <div class="singel_about_left mb-30">
                        <div class="singel_about_left_inner mb-3">
                            <div class="singel-about-content boder pl-4">
                                <?php echo $about->description; ?>

                            </div>
                        </div>
                        <div class="singel_about_left_inner pl-4">
                            <div class="button two">
                                <a href="#">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--==================================================-->
    <!----- End eTaxPlanner About Area ----->
    <!--==================================================-->


    <?php if (isset($component)) { $__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Service::class, []); ?>
<?php $component->withName('service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c)): ?>
<?php $component = $__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c; ?>
<?php unset($__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Team::class, []); ?>
<?php $component->withName('team'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f)): ?>
<?php $component = $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f; ?>
<?php unset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Testimonial::class, []); ?>
<?php $component->withName('testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff)): ?>
<?php $component = $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff; ?>
<?php unset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Brand::class, []); ?>
<?php $component->withName('brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e)): ?>
<?php $component = $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e; ?>
<?php unset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/about_us.blade.php ENDPATH**/ ?>