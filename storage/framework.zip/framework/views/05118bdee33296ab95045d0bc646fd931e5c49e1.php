

<?php $__env->startSection("title","Download / Upload Tax documents"); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>Download or Upload Tax Document</h5>
                </div>

                <div class="card-body">
                    <div class="row">

                        <div class="col-12 mt-4">
                            <div class="d-flex">
                                <div class="mr-3 text-primary">Documents Uploads / Downloads</div>
                                <div class="flex-grow-1 border-bottom align-self-center "></div>
                            </div>
                        </div>


                        <div class="col-md-8 offset-md-4">
                            <ul class="list-group">
                                <?php $__currentLoopData = $user_downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->id() == $download->added_by): ?>
                                        <li class="list-group-item  d-flex justify-content-between align-items-center">
                                            <span><?php echo e($download->filename); ?></span>
                                            <div class="d-flex justify-content-center">
                                                <form
                                                    action="<?php echo e(route_with_year('download_tax_documents_download',['id'=>$download->id])); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary btn-sm mr-2"><i
                                                            class="fa fa-download"></i></button>
                                                </form>

                                                <form
                                                    action="<?php echo e(route_with_year('download_tax_documents_delete',['id'=>$download->id])); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i
                                                            class="fa fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if(count($user_downloads) == 0): ?>
                                    <li class="list-group-item  d-flex justify-content-between align-items-center">
                                        <span>No documents uploaded</span>
                                    </li>
                                <?php endif; ?>
                            </ul>

                            <form action="<?php echo e(route_with_year('download_tax_documents_store')); ?>"
                                  enctype="multipart/form-data"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <div class="mt-3">

                                    <input type="file" hidden id="uploadFile" name="file"
                                           onchange="form.submit()">

                                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>)
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label class="btn btn-primary" for="uploadFile">
                                        <i class="fa fa-upload"></i>
                                        Upload File
                                    </label>
                                </div>
                            </form>
                        </div>


                        <div class="col-12 mt-4">
                            <div class="d-flex">
                                <div class="mr-3 text-primary">Documents From Authority</div>
                                <div class="flex-grow-1 border-bottom align-self-center"></div>
                            </div>
                        </div>


                        <div class="col-md-8 offset-md-4">
                            <ul class="list-group">
                                <?php $__currentLoopData = $org_downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item  d-flex justify-content-between align-items-center">
                                        <span><?php echo e($download->filename); ?></span>
                                        <div class="d-flex justify-content-center">
                                            <form
                                                action="<?php echo e(route_with_year('download_tax_documents_download',['id'=>$download->id])); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary btn-sm"><i
                                                        class="fa fa-download"></i></button>
                                            </form>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if(count($org_downloads) == 0): ?>
                                    <li class="list-group-item  d-flex justify-content-between align-items-center">
                                        <span>No documents uploaded</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>


                        <div class="col-12 mt-4">
                            <div class="d-flex">
                                <div class="mr-3 text-primary">Comments</div>
                                <div class="flex-grow-1 border-bottom align-self-center "></div>
                            </div>
                        </div>


                        <div class="col-md-12 mt-5">
                            <table class="table table-sm table-striped">
                                <thead>
                                <tr>
                                    <th>Commented By</th>
                                    <th>Comments</th>
                                    <th>Date Time</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($comment->commenter->name); ?></td>
                                        <td><?php echo e($comment->comment); ?></td>
                                        <td><?php echo e($comment->created_at->format("d m,Y")); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-8 offset-md-4">
                            <form action="<?php echo e(route_with_year('comments_store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <textarea rows="5" name="comment" class="form-control"
                                              placeholder="Comments"></textarea>
                                </div>
                                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <button type="submit" class="btn btn-primary">Comment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/documents/tax_document_download.blade.php ENDPATH**/ ?>