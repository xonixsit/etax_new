

<?php $__env->startSection('title', 'Miscellaneous Details'); ?>

<?php $__env->startSection('content'); ?>
    <miscellaneous-information :miscellaneous-details='<?php echo json_encode($miscellaneous_details, 15, 512) ?>'></miscellaneous-information>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/tax/miscellaneous_details.blade.php ENDPATH**/ ?>