


<?php $__env->startSection('content'); ?>
    <bank-details :bank-details='<?php echo json_encode($bank_details??[], 15, 512) ?>'></bank-details>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/personal_info/bank.blade.php ENDPATH**/ ?>