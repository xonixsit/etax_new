

<?php $__env->startSection('title', 'Expense Details'); ?>

<?php $__env->startSection('content'); ?>
    <expense-details :expense='<?php echo json_encode($expense_details, 15, 512) ?>'></expense-details>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/tax/expense_details.blade.php ENDPATH**/ ?>