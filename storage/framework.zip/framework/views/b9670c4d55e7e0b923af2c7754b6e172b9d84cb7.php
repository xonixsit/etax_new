


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            
            <dependent-details></dependent-details>
        </div>

        <div class="col-md-6">
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <tr>
                        <th>Name</th>
                        <th>D.O.B</th>
                        <th>Relationship</th>
                        <th>SSN/ITIN</th>
                        <th>Visa Status</th>
                        <th>Action</th>
                    </tr>

                    <?php $__currentLoopData = $dependent_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(implode(" ",[$item->fname, $item->mname, $item->lname])); ?></td>
                            <td><?php echo e($item->date_of_birth); ?></td>
                            <td><?php echo e($item->relationship); ?></td>
                            <td><?php echo e($item->ssn); ?></td>
                            <td><?php echo e($item->visa_status); ?></td>
                            <td>
                                <form method="post"
                                      action="<?php echo e(route_with_year('dependent_details_destroy',['dependentDetail'=>$item->id])); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/personal_info/dependent.blade.php ENDPATH**/ ?>