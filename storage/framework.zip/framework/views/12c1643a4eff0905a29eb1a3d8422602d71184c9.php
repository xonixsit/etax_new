

<?php $__env->startSection('title', 'Page'); ?>


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-6"><h4 class="card-title">Pages</h4></div>
                <div class="col-md-6 text-right d-flex align-items-center justify-content-end"><a
                        href="<?php echo e(route('admin.page.create')); ?>"
                        class="btn btn-primary"><i class="fa fa-plus"></i>
                        Add Page
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body">
            <table class="table">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Slug</th>
                    <th width="200">Action</th>
                </tr>

                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($page->id); ?></td>
                        <td><?php echo e($page->title); ?></td>
                        <td><?php echo e($page->slug); ?></td>

                        <td>
                            <a href="<?php echo e(route('admin.page.edit',['page'=> $page->id])); ?>"
                               class="btn btn-primary btn-sm">
                                <i class="fa fa-edit"></i>
                                Edit
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.page.destroy', $page->id)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/page/index.blade.php ENDPATH**/ ?>