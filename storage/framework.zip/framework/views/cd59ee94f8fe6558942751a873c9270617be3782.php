


<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-12">
                <div class="section_title text_center mb-55">
                    <div class="section_main_title">
                        <h1>Year Dashboard</h1>
                    </div>
                    <div class="em_bar">
                        <div class="em_bar_bg"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="border border-primary rounded-lg shadow-sm p-4 bg-light">
                    <h4 class="font-weight-light border-bottom mb-4 pb-3">About Me</h4>
                    <div class="d-flex flex-column align-items-center my-4">
                        <div>
                            <div class="avatar avatar-xl">
                                <i class="fa fa-user-circle fa-5x"></i>
                            </div>
                        </div>
                        <div>
                            <h5 class="font-weight-bold mb-0"><?php echo e(auth()->user()->name); ?></h5>
                        </div>
                    </div>
                    <div class="">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-phone mr-1"></i>
                            <span><?php echo e(auth()->user()->address->mobile??'N/A'); ?></span>
                        </div>

                        <div class="d-flex align-items-center">
                            <i class="fa fa-envelope mr-1"></i>
                            <span><?php echo e(auth()->user()->email); ?></span>
                        </div>
                    </div>

                    <div class="mt-4">
                        <a href="<?php echo e(route_with_year('user_profile_view')); ?>" type="button" class="btn btn-primary btn-sm">
                            Change Password
                        </a>

                        <a href="<?php echo e(route_with_year('user_profile_view')); ?>" type="button" class="btn btn-light btn-sm">
                            Edit Profile
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-md-8 mt-3 mt-md-0">
                <div class="row">
                    <?php $__currentLoopData = range(date('Y')+1, 2020); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="etaxplanner_flipbox mb-30">
                                <div class="etaxplanner_flipbox_font">
                                    <div class="etaxplanner_flipbox_inner">
                                        <div class="etaxplanner_flipbox_icon">
                                            <div class="icon">
                                                <i class="flaticon-global-1"></i>
                                            </div>
                                        </div>
                                        <div class="">
                                            <h5 class="">TAX YEAR <?php echo e($year); ?></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="etaxplanner_flipbox_back">
                                    <div class="etaxplanner_flipbox_inner">
                                        <div class="flipbox_title">
                                            <h3>TAX YEAR <?php echo e($year); ?></h3>
                                        </div>
                                        <div class="flipbox_desc">
                                            
                                            <a href="<?php echo e(route_with_year('year.dashboard', ['year'=>$year])); ?>"
                                               class="btn btn-light">Click Here to Proceed</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Brand::class, []); ?>
<?php $component->withName('brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e)): ?>
<?php $component = $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e; ?>
<?php unset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/year_dashboard.blade.php ENDPATH**/ ?>