


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    Payment Info
                </div>
                <div class="card-body">
                    <form class="cmxform form-horizontal" method="POST" action="">
                        <?php echo csrf_field(); ?>
                        <input class="span12 " name="user_id" type="hidden" required value="<?php echo e(auth()->user()->id); ?>"/>

                        <table class="table">

                            <tr>
                                <th>Invoice</th>
                                <th>Title</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Payment Status</th>
                                <th>Details</th>
                            </tr>
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->invoice_id or ''); ?></td>
                                    <td><?php echo e($item->name or ''); ?></td>
                                    <td><?php echo e($item->total_amount or ''); ?></td>
                                    <td><?php echo e($item->updated_at or ''); ?></td>
                                    <td><span class="btn btn-success btn-xs">Paid</span></td>
                                    <td><a href="<?php echo e(route('invoice-details',['id'=>$item->id])); ?>">View Details</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/payment_info.blade.php ENDPATH**/ ?>