<div class="card">
    <div class="card-header">
        Project Details
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <?php if($project_details->count()): ?>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Project Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>City</th>
                        <th>State</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_3 = true; $__currentLoopData = $project_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                        <tr>

                            <td><?php echo e($item->client ?? ''); ?></td>
                            <td><?php echo e($item->project ?? ''); ?></td>
                            <td><?php echo e($item->start_date ?? ''); ?></td>
                            <td><?php echo e($item->end_date ?? ''); ?></td>
                            <td><?php echo e($item->city ?? ''); ?></td>
                            <td><?php echo e($item->state ?? ''); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/project_details.blade.php ENDPATH**/ ?>