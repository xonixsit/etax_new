


<?php $__env->startSection('title', 'My File Status'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">

        <div class="card-header">
            <h5 class="card-title">My File Status</h5>
        </div>

        <div class="card-body">
            <div class="row border-bottom bg-info text-white py-2">
                <div class="col-4">Status By</div>
                <div class="col-4">Status</div>
                <div class="col-4">Date Time</div>
            </div>

            <?php $__currentLoopData = $fileStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-4"><?php echo e($status->user->name); ?></div>
                    <div class="col-4"><?php echo e($statusList[$item->status]); ?></div>
                    <div class="col-4"><?php echo e($status->created_at); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($fileStatus) == 0): ?>
                <div class="row">
                    <div class="col-12">
                        <h5 class="font-weight-light text-center text-muted">No Data found</h5>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/my_file_status.blade.php ENDPATH**/ ?>