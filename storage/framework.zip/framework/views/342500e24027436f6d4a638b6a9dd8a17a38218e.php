<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item['type']=='single' && $item['publish']): ?>

        <li class="sub-menu <?php if($item['active']): ?> active <?php endif; ?> ">
            <a class="" href="<?php echo e($item['url']); ?>">
                <i class="<?php echo e($item['icon']); ?>"></i>
                <span><?php echo e($item['text']); ?></span>
            </a>
        </li>

    <?php elseif($item['publish']): ?>
        <li class="sub-menu  <?php if($item['active']): ?> active <?php endif; ?> ">
            <a href="javascript:void(0);" class="">
                <i class="<?php echo e($item['icon']); ?>"></i>
                <span><?php echo e($item['text']); ?></span>
                <span class="arrow"></span>
            </a>


            <ul class="sub pl-3" <?php if($item['active']): ?> style="display: block" <?php endif; ?> >
                <?php $__currentLoopData = $item['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_key => $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($submenu['publish']): ?>

                        <li class="<?php echo e($submenu['active'] ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e($submenu['url']); ?>">
                                <span><?php echo e($submenu['text']); ?></span>
                            </a>
                        </li>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH D:\etax_site_1912025\resources\views/components/side-menu.blade.php ENDPATH**/ ?>