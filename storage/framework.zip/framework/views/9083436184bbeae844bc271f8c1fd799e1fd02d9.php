


<?php $__env->startSection('title', 'Process Flow Chart'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">

        <div class="card-header">
            <h5 class="card-title">Process Flow Chart</h5>
        </div>

        <div class="card-body">
            <img src="<?php echo e(asset('images/process_flow_chart.png')); ?>" alt="Process Flow Chart" class="img-fluid"/>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/process_flow_chart.blade.php ENDPATH**/ ?>