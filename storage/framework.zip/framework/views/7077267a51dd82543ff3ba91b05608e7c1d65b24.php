<div class="card">
    <div class="card-header">
        Expenses
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-sm table-striped">
                <tr>
                    <th class="">SL No</th>
                    <th class="">Particulars</th>
                    <th class="">Tax Payer</th>
                    <th class="">Spouse</th>
                    <th class="">Remarks</th>
                </tr>

                <?php $__currentLoopData = range(0,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="expenses_table_body">
                        <td><?php echo e($item + 1); ?></td>
                        <td><?php echo e($expense_details['title'][$item] ?? ''); ?></td>
                        <td><?php echo e($expense_details['taxpayer'][$item] ?? ''); ?></td>
                        <td><?php echo e($expense_details['spouse'][$item] ?? ''); ?></td>
                        <td><?php echo e($expense_details['remark'][$item] ?? ''); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/expenses.blade.php ENDPATH**/ ?>