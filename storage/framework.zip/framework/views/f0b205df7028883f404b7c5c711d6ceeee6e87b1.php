


<?php $__env->startSection('title', 'Brands'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="card-title">Brands</h4>
                            </div>
                            <div class="col-md-6 text-right">
                                <a href="<?php echo e(route('admin.brand.create')); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus"></i>
                                    Add Brand
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table table-sm table-striped">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Logo</th>
                                <th>Status</th>
                            </tr>
                            </thead>

                            <tbody>

                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($brand->name); ?></td>
                                    <td>
                                        <img class="img-fluid" style="height:40px" src="<?php echo e(storage_asset($brand->logo)); ?>" alt="<?php echo e($brand->name); ?>">
                                    </td>

                                    <td></td>
                                    <td class="d-flex">
                                        <a href="<?php echo e(route('admin.brand.edit', $brand->id)); ?>"
                                           class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i>
                                            Edit
                                        </a>
                                        <form method="POST"
                                              action="<?php echo e(route('admin.brand.destroy',$brand->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                    class="btn btn-danger btn-sm mx-2">
                                                <i class="fa fa-trash"></i>
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/brand/index.blade.php ENDPATH**/ ?>