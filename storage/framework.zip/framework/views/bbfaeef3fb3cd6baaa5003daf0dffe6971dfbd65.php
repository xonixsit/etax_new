


<?php $__env->startSection('title', 'Edit About Page'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form method="POST" action="<?php echo e(route('admin.about_page.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit About Page</h4>
                    </div>

                    <div class="card-body">
                        <!-- Select Image -->
                        <div class="form-group">
                            <label for="image" class="text-dark">Select Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFile" name="image"
                                       accept="image/*"/>
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="d-block">
                                <img src="<?php echo e(storage_asset($about->image)); ?>" alt="Image" class="img-fluid"
                                     style="max-width: 50px;">

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="text-dark" for="note">Sort Note</label>
                            <input type="text" name="note" id="note" class="form-control" value="<?php echo e($about->note); ?>"/>
                        </div>

                        <div class="form-group">
                            <label class="text-dark" for="heading">Heading</label>
                            <input type="text" name="heading" id="heading" class="form-control"
                                   value="<?php echo e($about->heading); ?>"/>
                        </div>


                        <div class="form-group">
                            <label class="text-dark" for="subheading">Sub Heading</label>
                            <textarea name="subheading" id="subheading" rows="3"
                                      class="form-control"><?php echo e($about->subheading); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label class="text-dark" for="description">Description</label>
                            <textarea name="description" id="description"
                                      class="form-control"><?php echo e($about->description); ?></textarea>
                        </div>


                    </div>


                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/tinymce/4.8.0/tinymce.min.js"></script>

    <script>
        tinymce.init({
            selector: 'textarea#description',
            height: 200,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tiny.cloud/css/codepen.min.css'
            ]
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/about/edit.blade.php ENDPATH**/ ?>