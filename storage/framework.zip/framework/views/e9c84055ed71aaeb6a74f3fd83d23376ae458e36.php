

<?php $__env->startSection('title', 'Service'); ?>


<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Start eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->
    <div class="breatcome_area d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breatcome_title">
                        <div class="breatcome_title_inner pb-2">
                            <h2>Our Service</h2>
                        </div>
                        <div class="breatcome_content">
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right"></i> <a href="#">
                                        Pages</a> <i class="fa fa-angle-right"></i> <span>Our Service</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->
    <?php if (isset($component)) { $__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Service::class, []); ?>
<?php $component->withName('service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c)): ?>
<?php $component = $__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c; ?>
<?php unset($__componentOriginal43c61edec25b89956c248a9b2605909e4c61c41c); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CallToDo::class, []); ?>
<?php $component->withName('call-to-do'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4)): ?>
<?php $component = $__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4; ?>
<?php unset($__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Team::class, []); ?>
<?php $component->withName('team'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f)): ?>
<?php $component = $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f; ?>
<?php unset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Testimonial::class, []); ?>
<?php $component->withName('testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff)): ?>
<?php $component = $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff; ?>
<?php unset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Brand::class, []); ?>
<?php $component->withName('brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e)): ?>
<?php $component = $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e; ?>
<?php unset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/services.blade.php ENDPATH**/ ?>