<?php $__env->startSection('title', 'FAQ'); ?>

<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Start eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->
    <div class="breatcome_area d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breatcome_title">
                        <div class="breatcome_title_inner pb-2">
                            <h2>FAQ'S</h2>
                        </div>
                        <div class="breatcome_content">
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('home')); ?>">Home</a>
                                    <i class="fa fa-angle-right"></i>
                                    <a href="#">
                                        Pages</a> <i class="fa fa-angle-right"></i> <span>FAQ'S</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End eTaxPlanner Breatcome Area -->
    <!-- ============================================================== -->


    <!-- ============================================================== -->
    <!-- Start - eTaxPlanner FAQ Area -->
    <!-- ============================================================== -->
    <div class="faq_area bg_color2 pt-90 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title text_center mb-60 mt-3">
                        <div class="section_main_title">
                            <h1>Frequently Asked Questions</h1>
                        </div>
                        <div class="em_bar">
                            <div class="em_bar_bg"></div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-6">
                        <div class="single_faq mb-4">
                            <div class="single_faq_content">
                                <div class="single_faq_title pb-2">
                                    <h4><?php echo e($faq->question); ?></h4>
                                </div>
                                <div class="single_faq_text">
                                    <p><?php echo e($faq->answer); ?></p>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End - eTaxPlanner Team Area -->
    <!-- ============================================================== -->



    <?php if (isset($component)) { $__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CallToDo::class, []); ?>
<?php $component->withName('call-to-do'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4)): ?>
<?php $component = $__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4; ?>
<?php unset($__componentOriginal9a02539f4515b01b8475868947a4cb17a7676ec4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Team::class, []); ?>
<?php $component->withName('team'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f)): ?>
<?php $component = $__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f; ?>
<?php unset($__componentOriginal4e87815adf488e11d3a1ff66d2598d879810534f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Testimonial::class, []); ?>
<?php $component->withName('testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff)): ?>
<?php $component = $__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff; ?>
<?php unset($__componentOriginal78ad3fb58fed6850d629b74373c4565d01ad67ff); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Brand::class, []); ?>
<?php $component->withName('brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e)): ?>
<?php $component = $__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e; ?>
<?php unset($__componentOriginal7f9368f92077c398beb31022df19942c0d65b40e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/faq.blade.php ENDPATH**/ ?>