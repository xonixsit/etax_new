

<?php $__env->startSection('title', 'Residency Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <residency-details></residency-details>
        </div>

        <div class="col-md-6">
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead>
                    <tr>
                        <th>Tax Payer</th>
                        <th>Start Time</th>
                        x
                        <th>End Date</th>
                        <th>Spouse</th>
                        <th>Start Time</th>
                        <th>End Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $residency_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->payer); ?></td>
                            <td><?php echo e($item->start_date); ?></td>
                            <td><?php echo e($item->end_date); ?></td>
                            <td><?php echo e($item->spouse); ?></td>
                            <td><?php echo e($item->spouse_start_date); ?></td>
                            <td><?php echo e($item->spouse_end_date); ?></td>
                            <td>
                                <form method="post"
                                      action="<?php echo e(route_with_year('residency_details_destroy',['residency'=>$item->id])); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/user/tax/residency_details.blade.php ENDPATH**/ ?>