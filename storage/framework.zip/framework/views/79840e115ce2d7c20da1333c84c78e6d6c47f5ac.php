


<?php $__env->startSection('content'); ?>
    <spouse-details :spouse-details='<?php echo json_encode($spouse_information??[], 15, 512) ?>'
                    :user-spouse-status="<?php echo e($spouse_status); ?>"></spouse-details>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/personal_info/spouse.blade.php ENDPATH**/ ?>