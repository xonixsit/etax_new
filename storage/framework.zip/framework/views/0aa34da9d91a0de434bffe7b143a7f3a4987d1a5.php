

<?php $__env->startSection('title', 'Edit General Config'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <strong>General Config</strong>
                </div>


                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.general-config.update', $general_config->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="name" class="text-dark">Name</label>
                            <input type="text" class="form-control" id="name" name="name"
                                   value="<?php echo e($general_config->name); ?>">

                        </div>

                        <div class="form-group">
                            <label for="name" class="text-dark">Key</label>
                            <input type="text" class="form-control" id="name" name="key" disabled
                                   value="<?php echo e($general_config->key); ?>">

                        </div>


                        <div class="form-group">
                            <label for="value"  class="text-dark">Value</label>
                            <input type="text" class="form-control" id="value" name="value"
                                   value="<?php echo e($general_config->value); ?>">
                            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/general_config/edit.blade.php ENDPATH**/ ?>