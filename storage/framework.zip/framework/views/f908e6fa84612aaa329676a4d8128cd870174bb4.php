

<?php $__env->startSection('title', 'Project Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <project-details></project-details>
        </div>

        <div class="col-md-6">
            <div class="table-responsive">
                <table class="table table-bordered  table-sm">
                    <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Project Name</th>
                        <th>Start Time</th>
                        <th>End Date</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $project_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->client); ?></td>
                            <td><?php echo e($item->project); ?></td>
                            <td><?php echo e($item->start_date); ?></td>
                            <td><?php echo e($item->end_date); ?></td>
                            <td><?php echo e($item->city); ?></td>
                            <td><?php echo e($item->state); ?></td>
                            <td>
                                <form method="post"
                                      action="<?php echo e(route_with_year('project_details_destroy',['project'=>$item->id])); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/tax/project_details.blade.php ENDPATH**/ ?>