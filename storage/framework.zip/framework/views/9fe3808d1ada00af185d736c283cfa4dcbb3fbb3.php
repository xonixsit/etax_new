

<?php $__env->startSection('title', 'Create Page'); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('admin.page.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Create Page</h3>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label class="text-dark" for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Title"
                           value="<?php echo e(old('title')); ?>">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="text-dark" for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" placeholder="Slug"
                           value="<?php echo e(old('slug')); ?>">
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="text-dark" for="content">Content</label>
                    <textarea class="form-control" id="content" name="content" rows="3"><?php echo e(old('content')); ?></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/tinymce/4.8.0/tinymce.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/slugify@1.6.5/slugify.min.js"></script>
    <script>

        $(document).ready(function () {
            $('#title').on('keyup', function () {
                var title = $(this).val();
                var slug = slugify(title, {
                    lower: true,
                    replacement: '-',
                    remove: /[*+~.()'"!:@]/g,
                    strict: true
                });
                $('#slug').val(slug);
            });
        });

        tinymce.init({
            selector: 'textarea',
            height: 200,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tiny.cloud/css/codepen.min.css'
            ]
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/page/create.blade.php ENDPATH**/ ?>