<!--==================================================-->
<!----- Start eTaxPlanner Flipbox Area ----->
<!--==================================================-->
<div class="flipbox_area pages pt-85 pb-70">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section_title text_center mb-55">
                    <div class="section_sub_title uppercase mb-3">
                        <h6>SERVICES</h6>
                    </div>
                    <div class="section_main_title">
                        <h1>Provide Exclusive Services</h1>
                    </div>
                    <div class="em_bar">
                        <div class="em_bar_bg"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-6">
                    <div class="etaxplanner_flipbox mb-30">
                        <div class="etaxplanner_flipbox_font">
                            <div class="etaxplanner_flipbox_inner">
                                <div class="etaxplanner_flipbox_icon">
                                    <div class="icon">
                                        <i class="fa fa-<?php echo e($service->icon); ?>"></i>
                                    </div>
                                </div>
                                <div class="flipbox_title">
                                    <h3><?php echo e($service->name); ?></h3>
                                </div>
                                <div class="flipbox_desc">
                                    <?php echo e(\Illuminate\Support\Str::limit(strip_tags($service->description), 100, $end='...')); ?>

                                </div>
                            </div>
                        </div>
                        <div class="etaxplanner_flipbox_back "
                             style="background-image:url(<?php echo e(asset($service->image?\Storage::url($service->image):'assets/images/feature1.jpg')); ?>);">
                            <div class="etaxplanner_flipbox_inner">
                                <div class="flipbox_title">
                                    <h3><?php echo e($service->name); ?></h3>
                                </div>
                                <div class="flipbox_desc">
                                    <?php echo e(\Illuminate\Support\Str::limit(strip_tags($service->description), 100, $end='...')); ?>

                                </div>
                                <div class="flipbox_button">
                                    <?php if(filter_var($service->url, FILTER_VALIDATE_URL) === FALSE): ?>
                                        <a href="<?php echo e(route('service-page', $service->url)); ?>">Read More<i
                                                class="fa fa-angle-double-right"></i></a>
                                    <?php else: ?>
                                        <a href="<?php echo e($service->url); ?>">Read More<i
                                                class="fa fa-angle-double-right"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!--==================================================-->
<!----- End eTaxPlanner Flipbox Area ----->
<!--==================================================-->
<?php /**PATH D:\etax_site_1912025\resources\views/components/service.blade.php ENDPATH**/ ?>