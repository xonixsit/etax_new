

<?php $__env->startSection('content'); ?>
   <login></login>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/auth/login.blade.php ENDPATH**/ ?>