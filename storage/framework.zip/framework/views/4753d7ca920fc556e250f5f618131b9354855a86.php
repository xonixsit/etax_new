<div class="card">
    <div class="card-header">
        Employee
    </div>


    <div class="card-body">
        <div class="teble-responsive">
            <?php if($employer_details->count()): ?>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Employer Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>City</th>
                        <th>State</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $employer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr>

                            <td><?php echo e($item->name ?? ''); ?></td>
                            <td><?php echo e($item->start_date ?? ''); ?></td>
                            <td><?php echo e($item->end_date ?? ''); ?></td>
                            <td><?php echo e($item->city ?? ''); ?></td>
                            <td><?php echo e($item->state ?? ''); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/employe.blade.php ENDPATH**/ ?>