

<?php $__env->startSection('title', 'User Year Access'); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $("input[type='checkbox']").change(function () {
                var year = $(this).data('year');
                var value = $(this).is(':checked');

                var data = {
                    'year': year,
                    'value': value ? 1 : 0
                };


                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('admin.year_access.update')); ?>",
                    data: data,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (data) {
                        console.log(data);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title">Set Editable Access to User</h5>
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="text-dark" for="role">Edit Permission</label>

                        <?php $__currentLoopData = range(2016, date('Y')+1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input"
                                       id="checkBox<?php echo e($loop->index); ?>" data-year="<?php echo e($year); ?>"
                                       <?php if($years[$year]->user_can_edit??1): ?> checked <?php endif; ?>
                                       value="<?php echo e($year); ?>">
                                <label class="custom-control-label text-dark"
                                       for="checkBox<?php echo e($loop->index); ?>"><?php echo e($year); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/year_access.blade.php ENDPATH**/ ?>