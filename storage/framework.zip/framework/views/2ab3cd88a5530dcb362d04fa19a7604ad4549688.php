<!--==================================================-->
<!----- Start eTaxPlanner Brand One Area ----->
<!--==================================================-->

<div class="brand_area pt-50 pb-70 bg_color2">
    <div class="container">
        <div class="row">
            <!-- Start Section Tile -->
            <div class="col-lg-12">
                <div class="section_title text_center mb-50 mt-3">
                    <div class="section_main_title">
                        <h1>Our Payment Partners</h1>
                    </div>
                    <div class="em_bar">
                        <div class="em_bar_bg"></div>
                    </div>

                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                    <!--testimonial owl curousel -->
                    <div class="brand_list owl-carousel curosel-style">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Single Brand -->
                            <div class="col-lg-12">
                                <div class="single_brand">
                                    <div class="single_brand_thumb">
                                        <img class="img-fluid" src="<?php echo e(storage_asset($brand->logo)); ?>" alt=""/>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==================================================-->
<!----- End eTaxPlanner Brand One Area ----->
<!--==================================================-->
<?php /**PATH D:\etax_site_1912025\resources\views/components/brand.blade.php ENDPATH**/ ?>