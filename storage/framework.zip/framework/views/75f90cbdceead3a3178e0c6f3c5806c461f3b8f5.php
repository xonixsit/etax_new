<div class="card">
    <div class="card-header">
        Miscellaneous
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-striped table-sm">
                <tr>
                    <th class="sl_no">SL No</th>
                    <th class="">Particulars</th>
                    <th class="">Tax Payer</th>
                    <th class="">Amount</th>
                    <th class="">Remarks</th>
                    <th class="">Spouse</th>
                    <th class="">Amount</th>
                    <th class="">Remarks</th>
                </tr>

                <?php $__currentLoopData = range(0,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index+1); ?></td>
                        <td><?php echo e($miscell_details['title'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['taxpayer'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['amount'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['remark'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['spouse'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['s_amount'][$index] ?? ''); ?></td>
                        <td><?php echo e($miscell_details['s_remark'][$index] ?? ''); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/miscellaneous.blade.php ENDPATH**/ ?>