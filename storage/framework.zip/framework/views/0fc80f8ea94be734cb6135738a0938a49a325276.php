


<?php $__env->startSection('title', 'Invoice'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row pb-5">
            <div class="col-12">
                <h3 class="font-weight-light pb-5">Invoice Details - Pending Invoice</h3>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th width="50">Serial</th>
                            <th>Invoice Item</th>
                            <th>Price</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $invoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index +1); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td>$<?php echo e($item->price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="2" class="text-right">Total</td>
                            <td>$<?php echo e($invoice->total_amount); ?></td>
                        </tfoot>
                    </table>
                </div>
                <div class="col-md-8">
                    <div class="form-group">
                        <label for="" class="col-form-label text-dark">Payment Link</label>
                        <textarea class="form-control"><?php echo e($invoice->description); ?></textarea>
					
                    </div>
                </div>

                <div class="d-flex justify-content-center">
                
                
                

                <!-- Button Code for PayTabs Express Checkout -->
                    <?php if($invoice->payment_status == 0): ?>
                        <div class="text-center">
                            <div class="PT_express_checkout"></div>
                        </div>
                    <?php else: ?>
                        <div class="text-center">
                            <div class="alert alert-success">
                                <strong> Payment has been made.</strong>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/view_tax_summary.blade.php ENDPATH**/ ?>