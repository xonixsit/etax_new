

<?php $__env->startSection('title', 'Asset Details'); ?>

<?php $__env->startSection('content'); ?>
    <asset-details :asset-details='<?php echo json_encode($asset_details, 15, 512) ?>'></asset-details>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/user/tax/asset_details.blade.php ENDPATH**/ ?>