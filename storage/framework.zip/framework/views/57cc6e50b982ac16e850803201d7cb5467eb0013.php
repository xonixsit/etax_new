

<?php $__env->startSection('title', 'Edit Invoice'); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css"/>
    <link rel="stylesheet"
          href="//cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@x.x.x/dist/select2-bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="//cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-header  d-flex justify-content-between align-items-center">
                    <div class="h4">Edit Invoice</div>

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb py-0 my-0">
                            <?php $__currentLoopData = range((request('year')??date("Y"))-1, (request('year')??date("Y"))+1 ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="breadcrumb-item <?php if($year == request('year')): ?> active <?php endif; ?> ">
                                    <?php if($year != request('year')): ?>
                                        <a href="<?php echo e(route(\Illuminate\Support\Facades\Route::currentRouteName(),['user'=>$invoice->user_id, 'year'=>$year])); ?>">
                                            <?php echo e($year); ?>

                                        </a>
                                    <?php else: ?>
                                        <?php echo e($year); ?>

                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </nav>
                </div>

                <invoice-edit :user='<?php echo json_encode($user, 15, 512) ?>' :invoice='<?php echo json_encode($invoice, 15, 512) ?>'
                              :last-invoice-items='<?php echo json_encode($invoiceItems, 15, 512) ?>' invoice-link="<?php echo e($invoiceLink); ?>"></invoice-edit>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/admin/invoice/edit.blade.php ENDPATH**/ ?>