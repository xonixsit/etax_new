<div class="card">
    <div class="card-header">
        Residency
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <?php if($residency_details->count()): ?>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Tax Payer</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Spouse</th>
                        <th>Start Date</th>
                        <th>End Date</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_4 = true; $__currentLoopData = $residency_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_4 = false; ?>
                        <tr>

                            <td><?php echo e($item->payer); ?></td>
                            <td><?php echo e($item->start_date); ?></td>
                            <td><?php echo e($item->end_date); ?></td>
                            <td><?php echo e($item->spouse); ?></td>
                            <td><?php echo e($item->spouse_start_date); ?></td>
                            <td><?php echo e($item->spouse_end_date); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/etaxplanner.com/httpdocs/resources/views/partial/residency.blade.php ENDPATH**/ ?>