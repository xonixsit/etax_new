<!--==================================================-->
<!----- Start	eTaxPlanner Header Top Menu Area Css ----->
<!--==================================================-->
<div class="bg_color">
    <marquee class="p-0 m-0 text-white">
        <?php echo e(general_config('notification')); ?>

    </marquee>
</div>

<!--==================================================-->
<!----- End	eTaxPlanner Header Top Menu Area Css ----->
<!--===================================================-->

<!--==================================================-->
<!----- Start eTaxPlanner Main Menu Area ----->
<!--==================================================-->
<div id="sticky-header" class="etaxplanner_nav_manu d-md-none d-lg-block d-sm-none d-none">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="logo mt-4">
                    <a class="logo_img" href="<?php echo e(route('home')); ?>" title="etaxplanner">
                        <div class="d-flex">
                            <img src="<?php echo e(asset('assets/images/logo/etaxplanner_logo.png')); ?>" class="mr-4"
                                 style="width:3rem"
                                 alt=""/>
                            <div class="brand h3 font-weight-normal align-self-center mt-2">E Tax Planner</div>
                        </div>
                    </a>
                    <a class="main_sticky" href="<?php echo e(route('home')); ?>" title="etaxplanner">
                        <img src="<?php echo e(asset('assets/images/logo/etaxplanner_logo.png')); ?>" style="width:3rem"
                             alt="astute"/>

                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <nav class="etaxplanner_menu">
                    <ul class="nav_scroll">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('services')); ?>">Services</a></li>
                        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                        <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                        <li><a href="<?php echo e(route('page', 'tips')); ?>">Tips</a></li>
                        <li><a href="<?php echo e(route('referrals.create')); ?>">Referral</a></li>
                    </ul>
                    <div class="donate-btn-header">
                        <?php if(auth()->guard('web')->check()): ?>

                            <?php if(auth()->user()->role == "admin"): ?>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">Admin Panel</a>

                            <?php elseif(auth()->user()->role == "staff"): ?>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">Staff Panel</a>

                            <?php else: ?>
                                <a href="<?php echo e(route_with_year('dashboard')); ?>" class="btn btn-primary">Dashboard</a>
                            <?php endif; ?>

                        <?php else: ?>
                            <?php if(\Route::currentRouteName() != 'login'): ?>
                                <a class="dtbtn" href="<?php echo e(route('login')); ?>">Login</a>
                            <?php endif; ?>

                            <?php if(\Route::currentRouteName() != 'register'): ?>
                                <a class="dtbtn" href="<?php echo e(route('register')); ?>">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        <div class="d-inline-block ml-3">
                            <div class="dropdown">
                                <button
                                    class="btn btn-light   text-warning rounded-circle d-flex justify-content-center align-items-center bg-light position-relative"
                                    style="height:2.8rem; width:2.8rem;" type="button" id="dropdownMenuButton"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-bell"></i>
                                    <?php if(auth()->user()->unreadNotifications->count() !== 0): ?>
                                        <div class="position-absolute" style="top:-5px; right: -8px;"
                                             id="notificationCount">
                                        <span
                                            class="badge badge-danger"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </button>

                                <div class="dropdown-menu dropdown-menu-right shadow-sm" id="notificationDropdown"
                                     aria-labelledby="dropdownMenuButton">
                                    <!--Notification-->

                                    <div class="d-flex border-bottom pb-2 justify-content-between">
                                        <div class="font-weight-light ml-3 h5">Notifications</div>
                                        <a href="#" id="markAsRead"
                                           class=" float-right text-decoration-underline small mr-3">Mark all as
                                            read</a>
                                    </div>


                                    <?php $__currentLoopData = auth()->user()->unreadNotifications()->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($notification['link']); ?>" class="dropdown-item d-flex px-2 mt-2"
                                           style="width:25rem;">

                                            <div
                                                class="bg-light rounded-lg d-flex justify-content-center align-items-center mr-2"
                                                style="height: 3.2rem; width: 3.2rem;">
                                                <i class="<?php echo e($notification->data['icon']); ?>"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="d-flex justify-content-between">
                                                    <?php if($notification->read_at == null): ?>
                                                        <div
                                                            class="font-weight-bold"><?php echo e($notification->data['subject']); ?></div>
                                                    <?php else: ?>
                                                        <div><?php echo e($notification->data['subject']); ?></div>
                                                    <?php endif; ?>

                                                    <small>
                                                        <i class="fa fa-clock-o mr-2"></i><?php echo e($notification->created_at->diffForHumans()); ?>

                                                    </small>
                                                </div>
                                                <div class="text-muted small">
                                                    <?php echo e($notification->data['message']); ?>

                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(auth()->user()->unreadNotifications->count() == 0): ?>
                                        <div class="dropdown-item d-flex px-3 mt-2" style="min-width:20rem;">
                                            <div class="d-flex text-center justify-content-center">
                                                <span class="text-muted">No Notifications Found!</span>
                                            </div>
                                        </div>
                                    <?php endif; ?>


                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</div>

<!----- eTaxPlanner Mobile Menu Area ----->
<div class="mobile-menu-area d-sm-block d-md-block d-lg-none ">
    <div class="mobile-menu">
        <nav class="etaxplanner_menu">

            <ul class="nav_scroll">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('services')); ?>">Services</a></li>
                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                <li><a href="<?php echo e(route('page','tips')); ?>">Tips</a></li>
                <li><a href="<?php echo e(route('referrals.create')); ?>">Referral</a></li>


                <?php if(auth()->guard('web')->check()): ?>
                    <?php if(auth()->user()->role == "admin"): ?>
                        <li><a href="<?php echo e(route('admin.dashboard')); ?>">Admin Panel</a></li>

                    <?php elseif(auth()->user()->role == "staff"): ?>
                        <li><a href="#">Staff Panel</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route_with_year('year.dashboard')); ?>">Dashboard</a></li>
                    <?php endif; ?>

                <?php else: ?>
                    <?php if(\Route::currentRouteName() != 'login'): ?>
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <?php endif; ?>

                    <?php if(\Route::currentRouteName() != 'register'): ?>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php endif; ?>
                <?php endif; ?>

            </ul>
        </nav>
    </div>
</div>
<!--==================================================-->
<!----- End eTaxPlanner Main Menu Area ----->
<!--==================================================-->


<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            //Notification Mark as Read

            $('#markAsRead').click(function () {
                $.ajax({
                    url: '<?php echo e(route('notification.markAsRead')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },

                    success: function (data) {
                        console.log(data);
                        $('#notificationCount').text(0);
                        $('#notificationCount').hide();
                        $('#notificationDropdown').removeClass('show');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\etax_site_1912025\resources\views/shared/_header.blade.php ENDPATH**/ ?>