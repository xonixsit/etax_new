

<?php $__env->startSection('title', 'General Configuration'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">General Configuration</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover table-striped">
                            <thead class=" text-primary">
                            <th>
                                Name
                            </th>
                            <th>
                                Key
                            </th>
                            <th>
                                Value
                            </th>
                            <th>
                                Actions
                            </th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $configs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td >
                                        <?php echo e($config->name); ?>

                                    </td>

                                    <td class="user-select-all">
                                        <?php echo e($config->key); ?>

                                    </td>
                                    <td>
                                        <?php echo e($config->value); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.general-config.edit', $config->id)); ?>"
                                           class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i>
                                            Edit
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\etax_site_1912025\resources\views/admin/general_config/index.blade.php ENDPATH**/ ?>